# Chuẩn Ahimum và ưu tiên phản hồi

## Cập nhật 27/10/2026

Mạnh yêu cầu 5 ảnh khác nhau, phụ kiện phù hợp với back; ảnh phải thật như 5 ảnh đã gửi và thư mục chuẩn. Nền có thể là ảnh chụp địa điểm Hà Nội, Sài Gòn, khu du lịch, biển hoặc du thuyền khi hợp mẫu và câu chuyện. Đây là ví dụ bối cảnh, không bắt buộc đưa cả5 vào mỗi bộ. Ưu tiên người thật + nền thật + phụ kiện chuẩn; không thay bằng style fantasy chỉ vì bắt mắt.

Số ảnh theo brief hiện hành. Yêu cầu trước đó: 6concept×5ảnh RP4; sau đó phân loại đủ5nhóm, mỗi nhóm10concept; L01 tập trung2câu chuyện Tết/ngày hội và ngày cưới khoảng20ảnh/câu chuyện. Đây là các phạm vi từng vòng, không phải số lượng cố định của skill. Đọc yêu cầu mới nhất trước khi bắt đầu.

## Bài học từ 5 ảnh chuẩn đi kèm

- Da có chuyển sắc và độ mềm thật; tóc có sợi, khoảng rối vừa phải; mắt và biểu cảm không đồng đều theo một công thức. Không ép miệng cười lớn.
- Người hòa trong cảnh: mép tóc/áo không halo, độ nét và hướng sáng ăn với cửa gỗ, tường, bậc đá/gạch, lá và vùng xa. Không tách người siêu nét khỏi nền blur kem đồng loạt.
- Vải ngà có nếp rủ, độ bóng không đều và vùng vân rộng/không đều. Không thay bằng bông khô, vân hoa nhỏ sắc nét lặp lại hoặc nhựa bóng đều. Nhận xét thị giác không xác nhận thành phần sợi.
- Tay xách giỏ có điểm kẹp, quai căng và hướng rơi; tay chạm cột/cành có tiếp xúc. Chân/dép có trọng lượng, hình đế liên tục theo góc nhìn. Soi lại từng cảnh, không mặc định nguồn được gửi nghĩa mọi chi tiết đều phù hợp quảng cáo.
- Cảnh có lớp gần–giữa–xa và khoảng thở đủ; không bắt buộc tường trống. Một cử chỉ tự nhiên có thể là điểm chính.

Ảnh chuẩn là tham chiếu về độ thật, không phải quyền sao chép mọi đạo cụ, hỏng hóc, pose hoặc background sang toàn bộ concept. Một góc dép trông tách đế vẫn phải kiểm ở bản nguồn/ảnh khác.

## Các lỗi đã bị bác

- Vải áo trong bị khô/cứng, khác màu/vân; trộn cổ áo khác mẫu. Giữ mã nguồn và strictLook, kiểm vải ở ánh sáng tương đương, không dùng điểm đẹp chung thay kiểm sản phẩm.
- Thiệp vốn phải cầm bị chuyển lên tường. Đạo cụ phải phục vụ hành động thấy được; không viết caption “mở/đọc thiệp” khi ảnh chỉ cầm hoặc không cầm.
- 5pose/background được gọi là5concept; nhiều crop từ một khoảnh khắc được gọi là nhiều hành động. Phân biệt rõ.
- Ảnh cận chọn từ nguồn có khe áo/nếp quần gây cảm giác rách/méo, ghim chỉnh phom hoặc motif bị cắt; tựQC86–91 vẫn bị bác. Bảo toàn nguồn và khả năng dùng cho quảng cáo là2cổng khác nhau.
- Giỏ/quai/phụ kiện và tay không chung lực/hành động, đế dép đứt, vật thể xuyên người, vải/da nhựa. Có lỗi bắt buộc thì loại, không lấy điểm trung bình che.
- Ảnh trông đẹp nhưng không nói được dịp, câu chuyện hay cơ chế nghệ thuật. Nêu ý tưởng và bằng chứng thị giác trong hình; không bù bằng đoạn phân tích dài.

## Nguồn mới và duyệt

Nguồn sản phẩm gốc: Drive1pPMFZxTZ8ZivOyj09zBDpOGR0MhOY2-0. Phân loại local5nhóm/6strictLooks là thị giác, không phải5SKU đã xác nhận. Không lấy file derivative trên web thay ảnh sản phẩm gốc.

Ngày27/10Mạnh chỉ thư mục1lZYOy7QVDLcUPeZlf3uXpiKQOiwpVpWH để lưu “ảnh mẫu được duyệt”; thư mục1nYg7h1Eeupt1-M62bG2ko1WRiGLedhSm là chuẩn “nhìn nó thật”. Giữ hai vai trò khác nhau. Việc có file trong thư mục không tự cấp quyền dùng duyệt cho ảnh mới, không tự suy ra toànconcept/caption/campaign đã duyệt.

Nhàn chốt V6H01 cụ thể07:50ngày25/10; đây là duyệt đúng phiên bản cũ, không duyệt RP3/RP4 hay các bộ sau. Điểm AI và nhận xét tích cực một phần không phải duyệt toàn bộ.
